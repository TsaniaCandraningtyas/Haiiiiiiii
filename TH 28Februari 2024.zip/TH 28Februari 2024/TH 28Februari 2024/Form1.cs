using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Security.Policy;
using System.Collections.Generic;
using System.Windows.Forms;

namespace TH_28Februari_2024
{
    public partial class Form1 : Form
    {
        int[,] nama;
        string words;
        public Form1()
        {
            InitializeComponent();
        }

        private void Play_Click(object sender, EventArgs e)
        {

            List<string> Katauser = new List<string>();
            int box1 = Convert.ToInt32(TBox_Kata1.Text.Length);
            int box2 = Convert.ToInt32(TBox_Kata2.Text.Length);
            int box3 = Convert.ToInt32(TBox_Kata3.Text.Length);
            int box4 = Convert.ToInt32(TBox_Kata4.Text.Length);
            int box5 = Convert.ToInt32(TBox_Kata5.Text.Length);
            if (box1 != 5 || box2 != 5 || box3 != 5 || box4 != 5 || box5 != 5)
            {
                MessageBox.Show("Jumlah Huruf Harus 5!");
            }
            else if (TBox_Kata1.Text == TBox_Kata2.Text || TBox_Kata1.Text == TBox_Kata3.Text || TBox_Kata1.Text == TBox_Kata4.Text || TBox_Kata1.Text == TBox_Kata5.Text)
            {
                MessageBox.Show("Hindari Persamaan Kata!");
            }
            else if (TBox_Kata2.Text == TBox_Kata3.Text || TBox_Kata2.Text == TBox_Kata4.Text || TBox_Kata2.Text == TBox_Kata5.Text)
            {
                MessageBox.Show("Hindari Persamaan Kata!");
            }
            else if (TBox_Kata3.Text == TBox_Kata4.Text || TBox_Kata3.Text == TBox_Kata5.Text)
            {
                MessageBox.Show("Hindari Persamaan Kata!");
            }
            else if (TBox_Kata4.Text == TBox_Kata5.Text)
            {
                MessageBox.Show("Hindari Persamaan Kata!");
            }
            else
            {
                Kotak1.Visible = false;
            }
            MessageBox.Show("Mulai Permainan");
            Kotak2.Visible = true;
            Katauser.Add(TBox_Kata1.Text);
            Katauser.Add(TBox_Kata2.Text);
            Katauser.Add(TBox_Kata3.Text);
            Katauser.Add(TBox_Kata4.Text);
            Katauser.Add(TBox_Kata5.Text);
            Random rnd = new Random();
            int z = rnd.Next(0, 5);
            words = Katauser[z].ToUpper();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Permainan Tebak Kata");
            Kotak2.Visible = false;
        }

        private void Q_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (words[i] == 'Q')
                {
                    i = i + i;
                    lb_Huruf1.Text = lb_Huruf1.Text.Remove(i, 1);
                    lb_Huruf1.Text = lb_Huruf1.Text.Insert(i, 'Q'.ToString());
                }
            }
            bool benar = true;
            string kata = "";
            foreach (var huruf in lb_Huruf1.Text)
            {
                if (huruf != ' ')
                {
                    kata += huruf;
                }
            }
            for (int i = 0; i < 5; i++)
            {
                if (words[i].ToString() == kata[i].ToString())
                {
                    benar = true;
                }
            }
            if (benar == true)
            {
                MessageBox.Show("Permainan Selesai");
            }
        }

        private void W_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                
                if (words[i] == 'W')
                {
                    i = i + i;
                    lb_Huruf1.Text = lb_Huruf1.Text.Remove(i, i);
                    lb_Huruf1.Text = lb_Huruf1.Text.Insert(i, 'W'.ToString());
                }
            }
            bool benar = true;
            string kata = "";
            foreach (var huruf in lb_Huruf1.Text)
            {
                if (huruf != ' ')
                {
                    kata += huruf;
                }
            }
            for (int i = 0; i < 5; i++)
            {
                if (words[i].ToString() == kata[i].ToString())
                {
                    benar = true;
                }
            }
            if (benar == true)
            {
                MessageBox.Show("Permainan Selesai");
            }
        }

        private void E_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (words[i] == 'E')
                {
                    i = i + i;
                    lb_Huruf1.Text = lb_Huruf1.Text.Remove(i, 1);
                    lb_Huruf1.Text = lb_Huruf1.Text.Insert(i, 'E'.ToString());
                }
            }
            bool benar = true;
            string kata = "";
            foreach (var huruf in lb_Huruf1.Text)
            {
                if (huruf != ' ')
                {
                    kata += huruf;
                }
            }
            for (int i = 0; i < 5; i++)
            {
                if (words[i].ToString() == kata[i].ToString())
                {
                    benar = true;
                }
            }
            if (benar == true)
            {
                MessageBox.Show("Permainan Selesai");
            }
        }

        private void R_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (words[i] == 'R')
                {
                    i = i + i;
                    lb_Huruf1.Text = lb_Huruf1.Text.Remove(i, 1);
                    lb_Huruf1.Text = lb_Huruf1.Text.Insert(i, 'R'.ToString());
                }
            }
            bool benar = true;
            string kata = "";
            foreach (var huruf in lb_Huruf1.Text)
            {
                if (huruf != ' ')
                {
                    kata += huruf;
                }
            }
            for (int i = 0; i < 5; i++)
            {
                if (words[i].ToString() == kata[i].ToString())
                {
                    benar = true;
                }
            }
            if (benar == true)
            {
                MessageBox.Show("Permainan Selesai");
            }
        }

        private void T_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (words[i] == 'T')
                {
                    i = i + i;
                    lb_Huruf1.Text = lb_Huruf1.Text.Remove(i, 1);
                    lb_Huruf1.Text = lb_Huruf1.Text.Insert(i, 'T'.ToString());
                }
            }
            bool benar = true;
            string kata = "";
            foreach (var huruf in lb_Huruf1.Text)
            {
                if (huruf != ' ')
                {
                    kata += huruf;
                }
            }
            for (int i = 0; i < 5; i++)
            {
                if (words[i].ToString() == kata[i].ToString())
                {
                    benar = true;
                }
            }
            if (benar == true)
            {
                MessageBox.Show("Permainan Selesai");
            }
        }

        private void Y_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (words[i] == 'Y')
                {
                    i = i + i;
                    lb_Huruf1.Text = lb_Huruf1.Text.Remove(i, 1);
                    lb_Huruf1.Text = lb_Huruf1.Text.Insert(i, 'Y'.ToString());
                }
            }
            bool benar = true;
            string kata = "";
            foreach (var huruf in lb_Huruf1.Text)
            {
                if (huruf != ' ')
                {
                    kata += huruf;
                }
            }
            for (int i = 0; i < 5; i++)
            {
                if (words[i].ToString() == kata[i].ToString())
                {
                    benar = true;
                }
            }
            if (benar == true)
            {
                MessageBox.Show("Permainan Selesai");
            }
        }

        private void U_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (words[i] == 'U')
                {
                    i = i + i;
                    lb_Huruf1.Text = lb_Huruf1.Text.Remove(i, 1);
                    lb_Huruf1.Text = lb_Huruf1.Text.Insert(i, 'U'.ToString());
                }
            }
            bool benar = true;
            string kata = "";
            foreach (var huruf in lb_Huruf1.Text)
            {
                if (huruf != ' ')
                {
                    kata += huruf;
                }
            }
            for (int i = 0; i < 5; i++)
            {
                if (words[i].ToString() == kata[i].ToString())
                {
                    benar = true;
                }
            }
            if (benar == true)
            {
                MessageBox.Show("Permainan Selesai");
            }

        }

        private void I_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (words[i] == 'I')
                {
                    i = i + i;
                    lb_Huruf1.Text = lb_Huruf1.Text.Remove(i, 1);
                    lb_Huruf1.Text = lb_Huruf1.Text.Insert(i, 'I'.ToString());
                }
            }
            bool benar = true;
            string kata = "";
            foreach (var huruf in lb_Huruf1.Text)
            {
                if (huruf != ' ')
                {
                    kata += huruf;
                }
            }
            for (int i = 0; i < 5; i++)
            {
                if (words[i].ToString() == kata[i].ToString())
                {
                    benar = true;
                }
            }
            if (benar == true)
            {
                MessageBox.Show("Permainan Selesai");
            }

        }

        private void O_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (words[i] == 'O')
                {
                    i = i + i;
                    lb_Huruf1.Text = lb_Huruf1.Text.Remove(i, 1);
                    lb_Huruf1.Text = lb_Huruf1.Text.Insert(i, 'O'.ToString());
                }
            }
            bool benar = true;
            string kata = "";
            foreach (var huruf in lb_Huruf1.Text)
            {
                if (huruf != ' ')
                {
                    kata += huruf;
                }
            }
            for (int i = 0; i < 5; i++)
            {
                if (words[i].ToString() == kata[i].ToString())
                {
                    benar = true;
                }
            }
            if (benar == true)
            {
                MessageBox.Show("Permainan Selesai");
            }

        }

        private void P_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (words[i] == 'P')
                {
                    i = i + i;
                    lb_Huruf1.Text = lb_Huruf1.Text.Remove(i, 1);
                    lb_Huruf1.Text = lb_Huruf1.Text.Insert(i, 'P'.ToString());
                }
            }
            bool benar = true;
            string kata = "";
            foreach (var huruf in lb_Huruf1.Text)
            {
                if (huruf != ' ')
                {
                    kata += huruf;
                }
            }
            for (int i = 0; i < 5; i++)
            {
                if (words[i].ToString() == kata[i].ToString())
                {
                    benar = true;
                }
            }
            if (benar == true)
            {
                MessageBox.Show("Permainan Selesai");
            }
        }

        private void A_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (words[i] == 'A')
                {
                    i = i + i;
                    lb_Huruf1.Text = lb_Huruf1.Text.Remove(i, 1);
                    lb_Huruf1.Text = lb_Huruf1.Text.Insert(i, 'A'.ToString());
                }
            }

        }

        private void S_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (words[i] == 'S')
                {
                    i = i + i;
                    lb_Huruf1.Text = lb_Huruf1.Text.Remove(i, 1);
                    lb_Huruf1.Text = lb_Huruf1.Text.Insert(i, 'S'.ToString());
                }
            }
            bool benar = true;
            string kata = "";
            foreach (var huruf in lb_Huruf1.Text)
            {
                if (huruf != ' ')
                {
                    kata += huruf;
                }
            }
            for (int i = 0; i < 5; i++)
            {
                if (words[i].ToString() == kata[i].ToString())
                {
                    benar = true;
                }
            }
            if (benar == true)
            {
                MessageBox.Show("Permainan Selesai");
            }
        }

        private void D_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (words[i] == 'D')
                {
                    i = i + i;
                    lb_Huruf1.Text = lb_Huruf1.Text.Remove(i, 1);
                    lb_Huruf1.Text = lb_Huruf1.Text.Insert(i, 'D'.ToString());
                }
            }
            bool benar = true;
            string kata = "";
            foreach (var huruf in lb_Huruf1.Text)
            {
                if (huruf != ' ')
                {
                    kata += huruf;
                }
            }
            for (int i = 0; i < 5; i++)
            {
                if (words[i].ToString() == kata[i].ToString())
                {
                    benar = true;
                }
            }
            if (benar == true)
            {
                MessageBox.Show("Permainan Selesai");
            }
        }

        private void F_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (words[i] == 'F')
                {
                    i = i + i;
                    lb_Huruf1.Text = lb_Huruf1.Text.Remove(i, 1);
                    lb_Huruf1.Text = lb_Huruf1.Text.Insert(i, 'F'.ToString());
                }
            }
            bool benar = true;
            string kata = "";
            foreach (var huruf in lb_Huruf1.Text)
            {
                if (huruf != ' ')
                {
                    kata += huruf;
                }
            }
            for (int i = 0; i < 5; i++)
            {
                if (words[i].ToString() == kata[i].ToString())
                {
                    benar = true;
                }
            }
            if (benar == true)
            {
                MessageBox.Show("Permainan Selesai");
            }
        }

        private void G_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (words[i] == 'G')
                {
                    i = i + i;
                    lb_Huruf1.Text = lb_Huruf1.Text.Remove(i, 1);
                    lb_Huruf1.Text = lb_Huruf1.Text.Insert(i, 'G'.ToString());
                }
            }
            bool benar = true;
            string kata = "";
            foreach (var huruf in lb_Huruf1.Text)
            {
                if (huruf != ' ')
                {
                    kata += huruf;
                }
            }
            for (int i = 0; i < 5; i++)
            {
                if (words[i].ToString() == kata[i].ToString())
                {
                    benar = true;
                }
            }
            if (benar == true)
            {
                MessageBox.Show("Permainan Selesai");
            }
        }

        private void H_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (words[i] == 'H')
                {
                    i = i + i;
                    lb_Huruf1.Text = lb_Huruf1.Text.Remove(i, 1);
                    lb_Huruf1.Text = lb_Huruf1.Text.Insert(i, 'H'.ToString());
                }
            }
            bool benar = true;
            string kata = "";
            foreach (var huruf in lb_Huruf1.Text)
            {
                if (huruf != ' ')
                {
                    kata += huruf;
                }
            }
            for (int i = 0; i < 5; i++)
            {
                if (words[i].ToString() == kata[i].ToString())
                {
                    benar = true;
                }
            }
            if (benar == true)
            {
                MessageBox.Show("Permainan Selesai");
            }
        }

        private void J_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (words[i] == 'J')
                {
                    i = i + i;
                    lb_Huruf1.Text = lb_Huruf1.Text.Remove(i, 1);
                    lb_Huruf1.Text = lb_Huruf1.Text.Insert(i, 'J'.ToString());
                }
            }
            bool benar = true;
            string kata = "";
            foreach (var huruf in lb_Huruf1.Text)
            {
                if (huruf != ' ')
                {
                    kata += huruf;
                }
            }
            for (int i = 0; i < 5; i++)
            {
                if (words[i].ToString() == kata[i].ToString())
                {
                    benar = true;
                }
            }
            if (benar == true)
            {
                MessageBox.Show("Permainan Selesai");
            }
        }

        private void K_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (words[i] == 'K')
                {
                    i = i + i;
                    lb_Huruf1.Text = lb_Huruf1.Text.Remove(i, 1);
                    lb_Huruf1.Text = lb_Huruf1.Text.Insert(i, 'K'.ToString());
                }
            }
            bool benar = true;
            string kata = "";
            foreach (var huruf in lb_Huruf1.Text)
            {
                if (huruf != ' ')
                {
                    kata += huruf;
                }
            }
            for (int i = 0; i < 5; i++)
            {
                if (words[i].ToString() == kata[i].ToString())
                {
                    benar = true;
                }
            }
            if (benar == true)
            {
                MessageBox.Show("Permainan Selesai");
            }
        }

        private void L_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (words[i] == 'L')
                {
                    i = i + i;
                    lb_Huruf1.Text = lb_Huruf1.Text.Remove(i, 1);
                    lb_Huruf1.Text = lb_Huruf1.Text.Insert(i, 'L'.ToString());
                }
            }
            bool benar = true;
            string kata = "";
            foreach (var huruf in lb_Huruf1.Text)
            {
                if (huruf != ' ')
                {
                    kata += huruf;
                }
            }
            for (int i = 0; i < 5; i++)
            {
                if (words[i].ToString() == kata[i].ToString())
                {
                    benar = true;
                }
            }
            if (benar == true)
            {
                MessageBox.Show("Permainan Selesai");
            }
        }

        private void Z_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (words[i] == 'Z')
                {
                    i = i + i;
                    lb_Huruf1.Text = lb_Huruf1.Text.Remove(i, 1);
                    lb_Huruf1.Text = lb_Huruf1.Text.Insert(i, 'Z'.ToString());
                }
            }
            bool benar = true;
            string kata = "";
            foreach (var huruf in lb_Huruf1.Text)
            {
                if (huruf != ' ')
                {
                    kata += huruf;
                }
            }
            for (int i = 0; i < 5; i++)
            {
                if (words[i].ToString() == kata[i].ToString())
                {
                    benar = true;
                }
            }
            if (benar == true)
            {
                MessageBox.Show("Permainan Selesai");
            }
        }

        private void X_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (words[i] == 'X')
                {
                    i = i + i;
                    lb_Huruf1.Text = lb_Huruf1.Text.Remove(i, 1);
                    lb_Huruf1.Text = lb_Huruf1.Text.Insert(i, 'X'.ToString());
                }
            }
            bool benar = true;
            string kata = "";
            foreach (var huruf in lb_Huruf1.Text)
            {
                if (huruf != ' ')
                {
                    kata += huruf;
                }
            }
            for (int i = 0; i < 5; i++)
            {
                if (words[i].ToString() == kata[i].ToString())
                {
                    benar = true;
                }
            }
            if (benar == true)
            {
                MessageBox.Show("Permainan Selesai");
            }
        }

        private void C_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (words[i] == 'C')
                {
                    i = i + i;
                    lb_Huruf1.Text = lb_Huruf1.Text.Remove(i, 1);
                    lb_Huruf1.Text = lb_Huruf1.Text.Insert(i, 'C'.ToString());
                }
            }
            bool benar = true;
            string kata = "";
            foreach (var huruf in lb_Huruf1.Text)
            {
                if (huruf != ' ')
                {
                    kata += huruf;
                }
            }
            for (int i = 0; i < 5; i++)
            {
                if (words[i].ToString() == kata[i].ToString())
                {
                    benar = true;
                }
            }
            if (benar == true)
            {
                MessageBox.Show("Permainan Selesai");
            }
        }

        private void V_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (words[i] == 'V')
                {
                    i = i + i;
                    lb_Huruf1.Text = lb_Huruf1.Text.Remove(i, 1);
                    lb_Huruf1.Text = lb_Huruf1.Text.Insert(i, 'V'.ToString());
                }
            }
            bool benar = true;
            string kata = "";
            foreach (var huruf in lb_Huruf1.Text)
            {
                if (huruf != ' ')
                {
                    kata += huruf;
                }
            }
            for (int i = 0; i < 5; i++)
            {
                if (words[i].ToString() == kata[i].ToString())
                {
                    benar = true;
                }
            }
            if (benar == true)
            {
                MessageBox.Show("Permainan Selesai");
            }
        }

        private void B_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (words[i] == 'B')
                {
                    i = i + i;
                    lb_Huruf1.Text = lb_Huruf1.Text.Remove(i, 1);
                    lb_Huruf1.Text = lb_Huruf1.Text.Insert(i, 'B'.ToString());
                }
            }
            bool benar = true;
            string kata = "";
            foreach (var huruf in lb_Huruf1.Text)
            {
                if (huruf != ' ')
                {
                    kata += huruf;
                }
            }
            for (int i = 0; i < 5; i++)
            {
                if (words[i].ToString() == kata[i].ToString())
                {
                    benar = true;
                }
            }
            if (benar == true)
            {
                MessageBox.Show("Permainan Selesai");
            }
        }

        private void N_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (words[i] == 'N')
                {
                    i = i + i;
                    lb_Huruf1.Text = lb_Huruf1.Text.Remove(i, 1);
                    lb_Huruf1.Text = lb_Huruf1.Text.Insert(i, 'N'.ToString());
                }
            }
            bool benar = true;
            string kata = "";
            foreach (var huruf in lb_Huruf1.Text)
            {
                if (huruf != ' ')
                {
                    kata += huruf;
                }
            }
            for (int i = 0; i < 5; i++)
            {
                if (words[i].ToString() == kata[i].ToString())
                {
                    benar = true;
                }
            }
            if (benar == true)
            {
                MessageBox.Show("Permainan Selesai");
            }
        }

        private void M_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                if (words[i] == 'M')
                {
                    i = i + i;
                    lb_Huruf1.Text = lb_Huruf1.Text.Remove(i, 1);
                    lb_Huruf1.Text = lb_Huruf1.Text.Insert(i, 'M'.ToString());
                }
            }
            bool benar = true;
            string kata = "";
            foreach (var huruf in lb_Huruf1.Text)
            {
                if (huruf != ' ')
                {
                    kata += huruf;
                }
            }
            for (int i = 0; i < 5; i++)
            {
                if (words[i].ToString() == kata[i].ToString())
                {
                    benar = true;
                }
            }
            if (benar == true)
            {
                MessageBox.Show("Permainan Selesai");
            }
        }

        private void Huruf1_Click(object sender, EventArgs e)
        {

            if (lb_Huruf1 != null)
            {
                Kotak2.Visible = false;
                MessageBox.Show("Permainan Selesai");
            }

        }

        private void Finish_Click(object sender, EventArgs e)
        {

        }
    }
}