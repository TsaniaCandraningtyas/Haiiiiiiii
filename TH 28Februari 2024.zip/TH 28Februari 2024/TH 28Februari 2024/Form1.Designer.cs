﻿namespace TH_28Februari_2024
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            TBox_Kata1 = new TextBox();
            lb_Kata1 = new Label();
            bt_Start = new Button();
            llb_Kata2 = new Label();
            lb_Kata3 = new Label();
            lb_Kata4 = new Label();
            lb_Kata5 = new Label();
            TBox_Kata5 = new TextBox();
            TBox_Kata4 = new TextBox();
            TBox_Kata3 = new TextBox();
            TBox_Kata2 = new TextBox();
            Kotak1 = new Panel();
            bt_Q = new Button();
            bt_W = new Button();
            bt_X = new Button();
            bt_Z = new Button();
            bt_R = new Button();
            bt_E = new Button();
            bt_C = new Button();
            bt_L = new Button();
            bt_K = new Button();
            bt_J = new Button();
            bt_H = new Button();
            bt_G = new Button();
            by_F = new Button();
            bt_D = new Button();
            bt_S = new Button();
            bt_A = new Button();
            bt_I = new Button();
            bt_B = new Button();
            bt_V = new Button();
            bt_P = new Button();
            bt_N = new Button();
            bt_Y = new Button();
            bt_O = new Button();
            bt_U = new Button();
            bt_T = new Button();
            bt_M = new Button();
            Kotak2 = new Panel();
            Huruf3 = new Label();
            lb_Huruf1 = new Label();
            Kotak1.SuspendLayout();
            Kotak2.SuspendLayout();
            SuspendLayout();
            // 
            // TBox_Kata1
            // 
            TBox_Kata1.Location = new Point(48, 12);
            TBox_Kata1.Name = "TBox_Kata1";
            TBox_Kata1.Size = new Size(110, 23);
            TBox_Kata1.TabIndex = 0;
            // 
            // lb_Kata1
            // 
            lb_Kata1.AutoSize = true;
            lb_Kata1.Location = new Point(3, 15);
            lb_Kata1.Name = "lb_Kata1";
            lb_Kata1.Size = new Size(42, 15);
            lb_Kata1.TabIndex = 1;
            lb_Kata1.Text = "Kata 1 ";
            // 
            // bt_Start
            // 
            bt_Start.Location = new Point(27, 235);
            bt_Start.Name = "bt_Start";
            bt_Start.Size = new Size(115, 23);
            bt_Start.TabIndex = 2;
            bt_Start.Text = "Start";
            bt_Start.UseVisualStyleBackColor = true;
            bt_Start.Click += Play_Click;
            // 
            // llb_Kata2
            // 
            llb_Kata2.AutoSize = true;
            llb_Kata2.Location = new Point(3, 52);
            llb_Kata2.Name = "llb_Kata2";
            llb_Kata2.Size = new Size(39, 15);
            llb_Kata2.TabIndex = 3;
            llb_Kata2.Text = "Kata 2";
            // 
            // lb_Kata3
            // 
            lb_Kata3.AutoSize = true;
            lb_Kata3.Location = new Point(3, 95);
            lb_Kata3.Name = "lb_Kata3";
            lb_Kata3.Size = new Size(39, 15);
            lb_Kata3.TabIndex = 4;
            lb_Kata3.Text = "Kata 3";
            // 
            // lb_Kata4
            // 
            lb_Kata4.AutoSize = true;
            lb_Kata4.Location = new Point(3, 138);
            lb_Kata4.Name = "lb_Kata4";
            lb_Kata4.Size = new Size(39, 15);
            lb_Kata4.TabIndex = 5;
            lb_Kata4.Text = "Kata 4";
            // 
            // lb_Kata5
            // 
            lb_Kata5.AutoSize = true;
            lb_Kata5.Location = new Point(3, 183);
            lb_Kata5.Name = "lb_Kata5";
            lb_Kata5.Size = new Size(39, 15);
            lb_Kata5.TabIndex = 6;
            lb_Kata5.Text = "Kata 5";
            // 
            // TBox_Kata5
            // 
            TBox_Kata5.Location = new Point(48, 180);
            TBox_Kata5.Name = "TBox_Kata5";
            TBox_Kata5.Size = new Size(110, 23);
            TBox_Kata5.TabIndex = 7;
            // 
            // TBox_Kata4
            // 
            TBox_Kata4.Location = new Point(48, 135);
            TBox_Kata4.Name = "TBox_Kata4";
            TBox_Kata4.Size = new Size(110, 23);
            TBox_Kata4.TabIndex = 8;
            // 
            // TBox_Kata3
            // 
            TBox_Kata3.Location = new Point(48, 92);
            TBox_Kata3.Name = "TBox_Kata3";
            TBox_Kata3.Size = new Size(110, 23);
            TBox_Kata3.TabIndex = 9;
            // 
            // TBox_Kata2
            // 
            TBox_Kata2.Location = new Point(48, 49);
            TBox_Kata2.Name = "TBox_Kata2";
            TBox_Kata2.Size = new Size(110, 23);
            TBox_Kata2.TabIndex = 10;
            // 
            // Kotak1
            // 
            Kotak1.Controls.Add(lb_Kata1);
            Kotak1.Controls.Add(TBox_Kata2);
            Kotak1.Controls.Add(TBox_Kata1);
            Kotak1.Controls.Add(TBox_Kata3);
            Kotak1.Controls.Add(bt_Start);
            Kotak1.Controls.Add(TBox_Kata4);
            Kotak1.Controls.Add(llb_Kata2);
            Kotak1.Controls.Add(TBox_Kata5);
            Kotak1.Controls.Add(lb_Kata3);
            Kotak1.Controls.Add(lb_Kata5);
            Kotak1.Controls.Add(lb_Kata4);
            Kotak1.Location = new Point(12, 32);
            Kotak1.Name = "Kotak1";
            Kotak1.Size = new Size(168, 283);
            Kotak1.TabIndex = 11;
            // 
            // bt_Q
            // 
            bt_Q.Location = new Point(12, 229);
            bt_Q.Name = "bt_Q";
            bt_Q.Size = new Size(60, 56);
            bt_Q.TabIndex = 12;
            bt_Q.Text = "Q";
            bt_Q.UseVisualStyleBackColor = true;
            bt_Q.Click += Q_Click;
            // 
            // bt_W
            // 
            bt_W.Location = new Point(72, 229);
            bt_W.Name = "bt_W";
            bt_W.Size = new Size(60, 56);
            bt_W.TabIndex = 13;
            bt_W.Text = "W";
            bt_W.UseVisualStyleBackColor = true;
            bt_W.Click += W_Click;
            // 
            // bt_X
            // 
            bt_X.Location = new Point(135, 343);
            bt_X.Name = "bt_X";
            bt_X.Size = new Size(60, 56);
            bt_X.TabIndex = 14;
            bt_X.Text = "X";
            bt_X.UseVisualStyleBackColor = true;
            bt_X.Click += X_Click;
            // 
            // bt_Z
            // 
            bt_Z.Location = new Point(74, 343);
            bt_Z.Name = "bt_Z";
            bt_Z.Size = new Size(60, 56);
            bt_Z.TabIndex = 15;
            bt_Z.Text = "Z";
            bt_Z.UseVisualStyleBackColor = true;
            bt_Z.Click += Z_Click;
            // 
            // bt_R
            // 
            bt_R.Location = new Point(192, 229);
            bt_R.Name = "bt_R";
            bt_R.Size = new Size(60, 56);
            bt_R.TabIndex = 16;
            bt_R.Text = "R";
            bt_R.UseVisualStyleBackColor = true;
            bt_R.Click += R_Click;
            // 
            // bt_E
            // 
            bt_E.Location = new Point(132, 229);
            bt_E.Name = "bt_E";
            bt_E.Size = new Size(60, 56);
            bt_E.TabIndex = 17;
            bt_E.Text = "E";
            bt_E.UseVisualStyleBackColor = true;
            bt_E.Click += E_Click;
            // 
            // bt_C
            // 
            bt_C.Location = new Point(196, 342);
            bt_C.Name = "bt_C";
            bt_C.Size = new Size(60, 56);
            bt_C.TabIndex = 18;
            bt_C.Text = "C";
            bt_C.UseVisualStyleBackColor = true;
            bt_C.Click += C_Click;
            // 
            // bt_L
            // 
            bt_L.Location = new Point(527, 284);
            bt_L.Name = "bt_L";
            bt_L.Size = new Size(60, 56);
            bt_L.TabIndex = 19;
            bt_L.Text = "L";
            bt_L.UseVisualStyleBackColor = true;
            bt_L.Click += L_Click;
            // 
            // bt_K
            // 
            bt_K.Location = new Point(466, 284);
            bt_K.Name = "bt_K";
            bt_K.Size = new Size(60, 56);
            bt_K.TabIndex = 20;
            bt_K.Text = "K";
            bt_K.UseVisualStyleBackColor = true;
            bt_K.Click += K_Click;
            // 
            // bt_J
            // 
            bt_J.Location = new Point(405, 284);
            bt_J.Name = "bt_J";
            bt_J.Size = new Size(60, 56);
            bt_J.TabIndex = 21;
            bt_J.Text = "J";
            bt_J.UseVisualStyleBackColor = true;
            bt_J.Click += J_Click;
            // 
            // bt_H
            // 
            bt_H.Location = new Point(345, 285);
            bt_H.Name = "bt_H";
            bt_H.Size = new Size(60, 56);
            bt_H.TabIndex = 22;
            bt_H.Text = "H";
            bt_H.UseVisualStyleBackColor = true;
            bt_H.Click += H_Click;
            // 
            // bt_G
            // 
            bt_G.Location = new Point(285, 285);
            bt_G.Name = "bt_G";
            bt_G.Size = new Size(60, 56);
            bt_G.TabIndex = 23;
            bt_G.Text = "G";
            bt_G.UseVisualStyleBackColor = true;
            bt_G.Click += G_Click;
            // 
            // by_F
            // 
            by_F.Location = new Point(226, 284);
            by_F.Name = "by_F";
            by_F.Size = new Size(60, 56);
            by_F.TabIndex = 24;
            by_F.Text = "F";
            by_F.UseVisualStyleBackColor = true;
            by_F.Click += F_Click;
            // 
            // bt_D
            // 
            bt_D.Location = new Point(166, 284);
            bt_D.Name = "bt_D";
            bt_D.Size = new Size(60, 56);
            bt_D.TabIndex = 25;
            bt_D.Text = "D";
            bt_D.UseVisualStyleBackColor = true;
            bt_D.Click += D_Click;
            // 
            // bt_S
            // 
            bt_S.Location = new Point(106, 285);
            bt_S.Name = "bt_S";
            bt_S.Size = new Size(60, 56);
            bt_S.TabIndex = 26;
            bt_S.Text = "S";
            bt_S.UseVisualStyleBackColor = true;
            bt_S.Click += S_Click;
            // 
            // bt_A
            // 
            bt_A.Location = new Point(46, 285);
            bt_A.Name = "bt_A";
            bt_A.Size = new Size(60, 56);
            bt_A.TabIndex = 27;
            bt_A.Text = "A";
            bt_A.UseVisualStyleBackColor = true;
            bt_A.Click += A_Click;
            // 
            // bt_I
            // 
            bt_I.Location = new Point(432, 229);
            bt_I.Name = "bt_I";
            bt_I.Size = new Size(60, 56);
            bt_I.TabIndex = 29;
            bt_I.Text = "I";
            bt_I.UseVisualStyleBackColor = true;
            bt_I.Click += I_Click;
            // 
            // bt_B
            // 
            bt_B.Location = new Point(317, 342);
            bt_B.Name = "bt_B";
            bt_B.Size = new Size(60, 56);
            bt_B.TabIndex = 30;
            bt_B.Text = "B";
            bt_B.UseVisualStyleBackColor = true;
            bt_B.Click += B_Click;
            // 
            // bt_V
            // 
            bt_V.Location = new Point(257, 342);
            bt_V.Name = "bt_V";
            bt_V.Size = new Size(60, 56);
            bt_V.TabIndex = 31;
            bt_V.Text = "V";
            bt_V.UseVisualStyleBackColor = true;
            bt_V.Click += V_Click;
            // 
            // bt_P
            // 
            bt_P.Location = new Point(552, 229);
            bt_P.Name = "bt_P";
            bt_P.Size = new Size(60, 56);
            bt_P.TabIndex = 32;
            bt_P.Text = "P";
            bt_P.UseVisualStyleBackColor = true;
            bt_P.Click += P_Click;
            // 
            // bt_N
            // 
            bt_N.Location = new Point(377, 341);
            bt_N.Name = "bt_N";
            bt_N.Size = new Size(60, 56);
            bt_N.TabIndex = 33;
            bt_N.Text = "N";
            bt_N.UseVisualStyleBackColor = true;
            bt_N.Click += N_Click;
            // 
            // bt_Y
            // 
            bt_Y.Location = new Point(312, 229);
            bt_Y.Name = "bt_Y";
            bt_Y.Size = new Size(60, 56);
            bt_Y.TabIndex = 34;
            bt_Y.Text = "Y";
            bt_Y.UseVisualStyleBackColor = true;
            bt_Y.Click += Y_Click;
            // 
            // bt_O
            // 
            bt_O.Location = new Point(492, 229);
            bt_O.Name = "bt_O";
            bt_O.Size = new Size(60, 56);
            bt_O.TabIndex = 35;
            bt_O.Text = "O";
            bt_O.UseVisualStyleBackColor = true;
            bt_O.Click += O_Click;
            // 
            // bt_U
            // 
            bt_U.Location = new Point(372, 229);
            bt_U.Name = "bt_U";
            bt_U.Size = new Size(60, 56);
            bt_U.TabIndex = 36;
            bt_U.Text = "U";
            bt_U.UseVisualStyleBackColor = true;
            bt_U.Click += U_Click;
            // 
            // bt_T
            // 
            bt_T.Location = new Point(252, 229);
            bt_T.Name = "bt_T";
            bt_T.Size = new Size(60, 56);
            bt_T.TabIndex = 37;
            bt_T.Text = "T";
            bt_T.UseVisualStyleBackColor = true;
            bt_T.Click += T_Click;
            // 
            // bt_M
            // 
            bt_M.Location = new Point(437, 340);
            bt_M.Name = "bt_M";
            bt_M.Size = new Size(60, 56);
            bt_M.TabIndex = 38;
            bt_M.Text = "M";
            bt_M.UseVisualStyleBackColor = true;
            bt_M.Click += M_Click;
            // 
            // Kotak2
            // 
            Kotak2.Controls.Add(Huruf3);
            Kotak2.Controls.Add(lb_Huruf1);
            Kotak2.Controls.Add(bt_T);
            Kotak2.Controls.Add(bt_Q);
            Kotak2.Controls.Add(bt_M);
            Kotak2.Controls.Add(bt_W);
            Kotak2.Controls.Add(bt_X);
            Kotak2.Controls.Add(bt_U);
            Kotak2.Controls.Add(bt_Z);
            Kotak2.Controls.Add(bt_O);
            Kotak2.Controls.Add(bt_R);
            Kotak2.Controls.Add(bt_Y);
            Kotak2.Controls.Add(bt_E);
            Kotak2.Controls.Add(bt_N);
            Kotak2.Controls.Add(bt_C);
            Kotak2.Controls.Add(bt_P);
            Kotak2.Controls.Add(bt_L);
            Kotak2.Controls.Add(bt_V);
            Kotak2.Controls.Add(bt_K);
            Kotak2.Controls.Add(bt_B);
            Kotak2.Controls.Add(bt_J);
            Kotak2.Controls.Add(bt_I);
            Kotak2.Controls.Add(bt_H);
            Kotak2.Controls.Add(bt_A);
            Kotak2.Controls.Add(bt_G);
            Kotak2.Controls.Add(bt_S);
            Kotak2.Controls.Add(by_F);
            Kotak2.Controls.Add(bt_D);
            Kotak2.Location = new Point(186, 32);
            Kotak2.Name = "Kotak2";
            Kotak2.Size = new Size(616, 406);
            Kotak2.TabIndex = 40;
            // 
            // Huruf3
            // 
            Huruf3.AutoSize = true;
            Huruf3.Location = new Point(270, 81);
            Huruf3.Name = "Huruf3";
            Huruf3.Size = new Size(0, 15);
            Huruf3.TabIndex = 41;
            // 
            // lb_Huruf1
            // 
            lb_Huruf1.AutoSize = true;
            lb_Huruf1.Font = new Font("Segoe UI", 72F, FontStyle.Regular, GraphicsUnit.Point);
            lb_Huruf1.Location = new Point(132, 47);
            lb_Huruf1.Name = "lb_Huruf1";
            lb_Huruf1.Size = new Size(358, 128);
            lb_Huruf1.TabIndex = 39;
            lb_Huruf1.Text = "_ _ _ _ _";
            lb_Huruf1.Click += Huruf1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(814, 450);
            Controls.Add(Kotak2);
            Controls.Add(Kotak1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            Kotak1.ResumeLayout(false);
            Kotak1.PerformLayout();
            Kotak2.ResumeLayout(false);
            Kotak2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TextBox TBox_Kata1;
        private Label lb_Kata1;
        private Button bt_Start;
        private Label llb_Kata2;
        private Label lb_Kata3;
        private Label lb_Kata4;
        private Label lb_Kata5;
        private TextBox TBox_Kata5;
        private TextBox TBox_Kata4;
        private TextBox TBox_Kata3;
        private TextBox TBox_Kata2;
        private Panel Kotak1;
        private Button bt_Q;
        private Button bt_W;
        private Button bt_X;
        private Button bt_Z;
        private Button bt_R;
        private Button bt_E;
        private Button bt_C;
        private Button bt_L;
        private Button bt_K;
        private Button bt_J;
        private Button bt_H;
        private Button bt_G;
        private Button by_F;
        private Button bt_D;
        private Button bt_S;
        private Button bt_A;
        private Button bt_I;
        private Button bt_B;
        private Button bt_V;
        private Button bt_P;
        private Button bt_N;
        private Button bt_Y;
        private Button bt_O;
        private Button bt_U;
        private Button bt_T;
        private Button bt_M;
        private Panel Kotak2;
        private Label Huruf3;
        private Label lb_Huruf1;
    }
}